﻿#include "gtest/gtest.h"
#include "MockDisplay.h"
#include "文字列電卓Mock_TestModel.h"
#include "StepCommand.h"

using namespace bdd;

// The model object will be created at the beginning of SETUP and
// will be deleted at the end of TEAR_DOWN.

// 文字列電卓Mock_TestModel* model;

SETUP(文字列電卓Mock_TestModel)
{
}

TEAR_DOWN()
{
}

// <数字文字列>を入力する
STEP1("<数字文字列>を入力する", GherkinRow&, row)
{
	model->Input(row[L"数字文字列"].strValue());
}

// <合計>が通知されること[[mock]]
STEP1("<合計>が通知されること[[mock]]", GherkinRow&, row)
{
	model->ExpectedSum(row[L"合計"].intValue());
}


