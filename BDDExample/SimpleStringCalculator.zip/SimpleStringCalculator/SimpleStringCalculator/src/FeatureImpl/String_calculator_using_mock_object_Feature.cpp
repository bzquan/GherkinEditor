﻿#ifdef WIN32
#pragma warning(disable : 4566)
#endif

#include "AbstractBDDTest.h"


// String_calculator_using_mock_object_Feature
class String_calculator_using_mock_object_Feature : public bdd::AbstractBDDTest
{
public:
    void SetUp() override
    {
        AbstractBDDTest::SetUp(L"String_calculator_using_mock_object");
        FeatureBackground();
    }

    void TearDown() override
    {
        AbstractBDDTest::TearDown(L"String_calculator_using_mock_object");
    }

    void FeatureBackground()
    {
    }
};

class ScenarioOutline_7a9b4aea_82c7_40a1_a3ce_d83d5802f0ac :
    public String_calculator_using_mock_object_Feature,
    public WithParamInterface<GherkinRow>
{
public:
    void SetUp() override
    {
        String_calculator_using_mock_object_Feature::SetUp();
        Spec("@guid-08173785-8ecc-3427-5807-f4d184e28ae8");
    }
};

TEST_P(ScenarioOutline_7a9b4aea_82c7_40a1_a3ce_d83d5802f0ac, A_separator_can_be___comma_or_semicolon)
{
    GherkinRow param = GetParam();

    Then(L"The result <Sum> shall be informed[[mock]]", param);
    When(L"Input <Numbers>", param);
}


static GherkinTable s_table_1(
        L"|Numbers  |Sum|\n"
        L"|1 + 2 + 3|6  |\n"
        L"|4, 5, 6  |15 |\n"
        L"|7; 8; 9  |24 |\n"
        L"|1, 2; 3  |0  |");

INSTANTIATE_TEST_CASE_P(
        String_calculator_using_mock_object_Feature_0,
        ScenarioOutline_7a9b4aea_82c7_40a1_a3ce_d83d5802f0ac,
        testing::ValuesIn(s_table_1.Rows()));


