﻿#ifdef WIN32
#pragma warning(disable : 4566)
#endif

#include "AbstractBDDTest.h"


// 文字列電卓_Feature
class 文字列電卓_Feature : public bdd::AbstractBDDTest
{
public:
    void SetUp() override
    {
        AbstractBDDTest::SetUp(L"文字列電卓");
        FeatureBackground();
    }

    void TearDown() override
    {
        AbstractBDDTest::TearDown(L"文字列電卓");
    }

    void FeatureBackground()
    {
    }
};

class ScenarioOutline_59b83f0e_87ba_40f0_806a_8d7a327c2252 :
    public 文字列電卓_Feature,
    public WithParamInterface<GherkinRow>
{
public:
    void SetUp() override
    {
        文字列電卓_Feature::SetUp();
        Spec("@guid-06c15960-4830-e419-58df-15e6c7a744a7");
    }
};

TEST_P(ScenarioOutline_59b83f0e_87ba_40f0_806a_8d7a327c2252, 数字文字列の合計)
{
    GherkinRow param = GetParam();

    Given(L"<数字文字列>がある", param);
    When(L"数字を合計する");
    Then(L"期待結果は<合計>であること", param);
}


static GherkinTable s_table_1(
        L"|数字文字列  |合計|\n"
        L"|            |0   |\n"
        L"|18          |18  |\n"
        L"|1 + 2 + 3   |6   |\n"
        L"|4, 5, 6     |15  |\n"
        L"|7; 8; 9     |24  |\n"
        L"|1, 2; 3     |0   |\n"
        L"|a1 + a2 + a3|0   |");

INSTANTIATE_TEST_CASE_P(
        文字列電卓_Feature_0,
        ScenarioOutline_59b83f0e_87ba_40f0_806a_8d7a327c2252,
        testing::ValuesIn(s_table_1.Rows()));


