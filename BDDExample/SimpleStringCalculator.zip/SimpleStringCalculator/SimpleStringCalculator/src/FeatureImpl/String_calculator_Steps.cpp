﻿#include "gtest/gtest.h"
#include "StringCalculator.h"
#include "StepCommand.h"

using namespace bdd;

// The model object will be created at the beginning of SETUP and
// will be deleted at the end of TEAR_DOWN.

// StringCalculator* model;

static int s_ActualSum = -1;

SETUP(StringCalculator)
{
	s_ActualSum = -1;
}

TEAR_DOWN()
{
}

// Enter <Numbers> with separator
STEP1("Enter <Numbers> with separator", GherkinRow&, row)
{
	model->Input(row[L"Numbers"].strValue());
}

// Sum all the numbers
STEP0("Sum all the numbers")
{
	s_ActualSum = model->CalculateSum();
}

// The result should be <Sum>
STEP1("The result should be <Sum>", GherkinRow&, row)
{
	ASSERT_EQ(row[L"Sum"].intValue(), s_ActualSum);
}


