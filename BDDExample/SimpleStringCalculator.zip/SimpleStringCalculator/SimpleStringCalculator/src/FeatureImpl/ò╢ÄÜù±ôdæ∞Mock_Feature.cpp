﻿#ifdef WIN32
#pragma warning(disable : 4566)
#endif

#include "AbstractBDDTest.h"


// 文字列電卓Mock_Feature
class 文字列電卓Mock_Feature : public bdd::AbstractBDDTest
{
public:
    void SetUp() override
    {
        AbstractBDDTest::SetUp(L"文字列電卓Mock");
        FeatureBackground();
    }

    void TearDown() override
    {
        AbstractBDDTest::TearDown(L"文字列電卓Mock");
    }

    void FeatureBackground()
    {
    }
};

class ScenarioOutline_d09b73c7_323c_48c3_ae93_42223255300e :
    public 文字列電卓Mock_Feature,
    public WithParamInterface<GherkinRow>
{
public:
    void SetUp() override
    {
        文字列電卓Mock_Feature::SetUp();
        Spec("@guid-05692578-2ff0-d490-487b-473121d9acfa");
    }
};

TEST_P(ScenarioOutline_d09b73c7_323c_48c3_ae93_42223255300e, 数字文字列の合計)
{
    GherkinRow param = GetParam();

    Then(L"<合計>が通知されること[[mock]]", param);
    When(L"<数字文字列>を入力する", param);
}


static GherkinTable s_table_1(
        L"|数字文字列  |合計|\n"
        L"|            |0   |\n"
        L"|18          |18  |\n"
        L"|1 + 2 + 3   |6   |\n"
        L"|4, 5, 6     |15  |\n"
        L"|7; 8; 9     |24  |\n"
        L"|1, 2; 3     |0   |\n"
        L"|a1 + a2 + a3|0   |");

INSTANTIATE_TEST_CASE_P(
        文字列電卓Mock_Feature_0,
        ScenarioOutline_d09b73c7_323c_48c3_ae93_42223255300e,
        testing::ValuesIn(s_table_1.Rows()));


