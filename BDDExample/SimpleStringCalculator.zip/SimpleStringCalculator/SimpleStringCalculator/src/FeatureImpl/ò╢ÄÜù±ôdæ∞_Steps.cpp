﻿#include "gtest/gtest.h"
#include "StringCalculator.h"
#include "StepCommand.h"

using namespace bdd;

// The model object will be created at the beginning of SETUP and
// will be deleted at the end of TEAR_DOWN.

// StringCalculator* model;

static int sum;

SETUP(StringCalculator)
{
	sum = -1;
}

TEAR_DOWN()
{
}

// <数字文字列>がある
STEP1("<数字文字列>がある", GherkinRow&, row)
{
    model->Input(row[L"数字文字列"].strValue());
}

// 数字を合計する
STEP0("数字を合計する")
{
	sum = model->CalculateSum();
}

// 期待結果は<合計>であること
STEP1("期待結果は<合計>であること", GherkinRow&, row)
{
	ASSERT_EQ(row[L"合計"].intValue(), sum);
}


