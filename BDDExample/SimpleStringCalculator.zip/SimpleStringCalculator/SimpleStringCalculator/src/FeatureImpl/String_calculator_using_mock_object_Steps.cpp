﻿#include "String_calculator_using_mock_object_TestModel.h"
#include "StepCommand.h"

using namespace bdd;

// The model object will be created at the beginning of SETUP and
// will be deleted at the end of TEAR_DOWN.

// String_calculator_using_mock_object_TestModel* model;

SETUP(String_calculator_using_mock_object_TestModel)
{
}

TEAR_DOWN()
{
}

// Input <Numbers>
STEP1("Input <Numbers>", GherkinRow&, row)
{
	model->Input(row[L"Numbers"].strValue());
}

// The result <Sum> shall be informed[[mock]]
STEP1("The result <Sum> shall be informed[[mock]]", GherkinRow&, row)
{
	model->ExpectedSum(row[L"Sum"].intValue());
}


