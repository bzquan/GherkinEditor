﻿#ifdef WIN32
#pragma warning(disable : 4566)
#endif

#include "AbstractBDDTest.h"


// String_calculator_Feature
class String_calculator_Feature : public bdd::AbstractBDDTest
{
public:
    void SetUp() override
    {
        AbstractBDDTest::SetUp(L"String_calculator");
        FeatureBackground();
    }

    void TearDown() override
    {
        AbstractBDDTest::TearDown(L"String_calculator");
    }

    void FeatureBackground()
    {
    }
};

class ScenarioOutline_0baa2e0a_cebb_4383_bc46_d482e6239bcb :
    public String_calculator_Feature,
    public WithParamInterface<GherkinRow>
{
public:
    void SetUp() override
    {
        String_calculator_Feature::SetUp();
        Spec("@guid-084139ff-dda8-440c-9941-f20a18464473");
    }
};

TEST_P(ScenarioOutline_0baa2e0a_cebb_4383_bc46_d482e6239bcb, A_separator_can_be___comma_or_semicolon)
{
    GherkinRow param = GetParam();

    Given(L"Enter <Numbers> with separator", param);
    When(L"Sum all the numbers");
    Then(L"The result should be <Sum>", param);
}


static GherkinTable s_table_1(
        L"|Numbers  |Sum|\n"
        L"|1 + 2 + 3|6  |\n"
        L"|4, 5, 6  |15 |\n"
        L"|7; 8; 9  |24 |\n"
        L"|1, 2; 3  |0  |");

INSTANTIATE_TEST_CASE_P(
        String_calculator_Feature_0,
        ScenarioOutline_0baa2e0a_cebb_4383_bc46_d482e6239bcb,
        testing::ValuesIn(s_table_1.Rows()));


