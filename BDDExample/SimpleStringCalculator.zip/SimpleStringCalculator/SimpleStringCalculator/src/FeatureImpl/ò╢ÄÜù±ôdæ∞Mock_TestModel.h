﻿#pragma once

#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include "MockDisplay.h"
#include "StringCalculator.h"

//文字列電卓Mock_TestModel
class 文字列電卓Mock_TestModel
{
public:
    文字列電卓Mock_TestModel() : m_Calculator(&m_MockDisplay) {}

    void SetUp();
    void TearDown();
    void Input(std::string input);
    void ExpectedSum(int sum);

private:
    MockDisplay      m_MockDisplay;
    StringCalculator m_Calculator;
};
